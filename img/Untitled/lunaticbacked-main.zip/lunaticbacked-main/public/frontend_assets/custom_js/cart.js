


$('#waitlist').on('submit',function(e){
      e.preventDefault();  
      $.ajaxSetup({
                  headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
              });
      $.ajax({    
         url:siteUrl +'/save_waitlist',      
         type:'post',      
         data:new FormData(this),      
         dataType:'json', 
         contentType:false,
         processData: false,    
         success:function(response){ 
            if(response.status_code ==200){
               toastr["success"](response.message);
               $("#waitlist").trigger("reset");
                // setTimeout( location.reload(),5000);        
            }else if(response.status_code==301){
               var dd = response.message ;
               for(var i=0; i<dd.length;i++){
                  toastr["error"](dd[i]);
               }
            }else if(response.status_code ==201){
               toastr["error"](response.message);
            }
            // else if(response.status == 4){
            //    toastr["success"]("data Updated");
            //    setTimeout( "redirect(siteUrl +'/view_product')",2000);  
            // }             
         },
      })
   });
