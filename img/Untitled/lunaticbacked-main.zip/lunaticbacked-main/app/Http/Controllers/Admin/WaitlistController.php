<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Waitlist};
use Validator;
use Yajra\DataTables\DataTables;
use Auth;
use Str;
use Schema;
use DB;
use Illuminate\Support\Arr;


class WaitlistController extends Controller
{
    public function index()
    {
      return view('admin.waitlist');
    }//end of method

    public function show(Request $request){
        if ($request->all()) {
            $data = Waitlist::where('is_deleted',0)->orderBy('id','DESC')->get();
            return DataTables::of($data)
                    ->addIndexColumn()
                    
                   

                    ->addColumn('status', function($row){
                        if ($row->newsletter == 1) {
                           $btn = '<span class="badge badge-success">Yes</span>';
                        }else{
                           $btn = '<span class="badge badge-danger">No</span>';

                        }
                          
                            return $btn;
                    })
                    ->rawColumns(['status'])
                    ->make(true);
        }
    }//end of method
}
