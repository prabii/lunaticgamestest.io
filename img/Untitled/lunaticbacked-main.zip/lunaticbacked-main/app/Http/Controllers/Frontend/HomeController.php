<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Partner,Waitlist};
use Validator;
use Auth;
use Str;
use Schema;
use DB;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Redirect;
use Softon\Indipay\Facades\Indipay;  
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

class HomeController extends Controller
{
    public function index()
    {
      $data['partner'] = Partner::where(['is_deleted'=>0,'active_status'=>1])->get();
      $data['title'] = 'Lunatic Games Studio | Home ';
      return view('frontend.home',$data);
    }//end of method


    public function story(Request $request)
    {
      $data['title'] = 'Lunatic Games Studio | Story ';
      return view('frontend.story',$data);
    }//end of method

    public function tokonomics(Request $request)
    {
      $data['title'] = 'Lunatic Games Studio | Tokonomics ';
      return view('frontend.tokonomics',$data);
    }//end of method

    public function elixir(Request $request)
    {
      $data['title'] = 'Lunatic Games Studio | elixir ';
      return view('frontend.elixir',$data);
    }//end of method

    public function waitlist(Request $request)
    {
      $data['title'] = 'Lunatic Games Studio | elixir ';
      return view('frontend.waitlist',$data);
    }//end of method

    public function save_waitlist(Request $request){
            $validator = Validator::make($request->all(),[
                'email'=>'required|regex:/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/|unique:waitlists',
                'name'=>'required',
            ]);
        if($validator->passes()) {
            $formdata['name'] = $request->name;
            $formdata['email'] = $request->email;
            $formdata['wallet_id'] = $request->wallet_id;
            if ($request->newsletter) {
              $formdata['newsletter'] = $request->newsletter;
            }else{
              $formdata['newsletter'] = 0;
            }
            if ($request->wallet_id) {
                $data = Waitlist::where(['wallet_id'=>$request->wallet_id])->first();
              if ($data) {
                return ['status_code' => 201 , 'message' => "wallet Id Already Registered"];
              }
            }
            $row = Waitlist::insertGetId($formdata);
            $msg = 'Joined Our Community';
                 if($row){
                    return ['status_code' => 200 , 'message' =>$msg];
                }else{
                    return ['status_code' => 201 , 'message' => "Something went wrong !"];
                }
            }
           
        return ['message'=>$validator->errors()->all(),'status_code'=>301];      
    }//end of method




}
